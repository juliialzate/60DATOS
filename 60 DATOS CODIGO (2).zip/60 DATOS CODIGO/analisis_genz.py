"""
=============================================================
Análisis Estadístico Descriptivo — Tiempo de Atención Gen Z
=============================================================
Autores : María Juliana Alzate Saavedra
          Sebastián Avendaño Rodriguez
Materia : Probabilidad y Estadística
          Universidad Distrital Francisco José de Caldas
Profesor: Alberto Acosta | Abril 2026
=============================================================
Dependencias Requeridas:
    pip install numpy pandas scipy plotly kaleido
=============================================================

Descripción General del Módulo:
-------------------------------
Este script realiza un análisis descriptivo exhaustivo sobre
una muestra de tiempos de atención de la Generación Z. 
Calcula y documenta paso a paso:
    1. Tabla de Frecuencias Agrupadas.
    2. Medidas de Tendencia Central (Media, Mediana, Moda).
    3. Medidas de Dispersión (Varianza, Desviación Estándar, 
       Coeficiente de Variación, Error Estándar).
    4. Medidas de Posición (Cuartiles, Quintiles, Percentiles) 
       usando interpolación lineal en la posición p(n+1).
    5. Medidas de Forma (Asimetría y Curtosis de Fisher).
    6. Visualizaciones interactivas/estáticas con Plotly 
       (Histogramas, Ojiva/Boxplot, Densidad).
"""

import os
import json
import numpy as np
import pandas as pd
from scipy.stats import norm as sp_norm
import plotly.graph_objects as go

# Ruta base del script y directorio de salida para reportes y gráficas
script_dir = os.path.dirname(os.path.abspath(__file__))
output_dir = os.path.join(script_dir, "output")
os.makedirs(output_dir, exist_ok=True)

def out_path(filename):
    return os.path.join(output_dir, filename)


# ╔══════════════════════════════════════════════════════════════════╗
# ║  0. DATASET                                                      ║
# ╚══════════════════════════════════════════════════════════════════╝

data = np.array([
     5,  6,  6,  7,  7,  8,  8,  9,  9, 10,
    10, 10, 11, 12, 12, 13, 13, 14, 14, 15,
    15, 16, 16, 17, 18, 18, 19, 19, 20, 20,
    21, 22, 22, 23, 24, 25, 26, 27, 28, 29,
    30, 32, 34, 35, 37, 38, 40, 41, 45, 48,
    50, 55, 60, 65, 70, 75, 80, 85, 90, 95,
])

n = len(data)           # número de observaciones = 60
data_sorted = np.sort(data)

print(f"n = {n} | min = {data.min()} min | max = {data.max()} min")


# ╔══════════════════════════════════════════════════════════════════╗
# ║  1. TABLA DE FRECUENCIAS                                         ║
# ╚══════════════════════════════════════════════════════════════════╝
"""
Construcción de la tabla de frecuencias agrupadas.
Se definen intervalos (bins) de amplitud c=10 para abarcar el rango [0, 100).
Se calculan:
    - fi : Frecuencia absoluta (conteo de datos en el intervalo).
    - hi : Frecuencia relativa (fi / n).
    - Fi : Frecuencia absoluta acumulada (suma sucesiva de fi).
    - Hi : Frecuencia relativa acumulada (suma sucesiva de hi).
"""

BINS   = np.arange(0, 101, 10)          # límites: 0, 10, 20, … , 100
labels = [f"[{BINS[i]}, {BINS[i+1]})" for i in range(len(BINS) - 1)]

# Paso 1: Frecuencia Absoluta (fi)
fi = np.array([
    np.sum((data >= BINS[i]) & (data < BINS[i + 1]))
    for i in range(len(BINS) - 1)
])

# Paso 2: Frecuencia Relativa (hi)
hi_rel = fi / n

# Paso 3: Acumuladas (Fi, Hi)
Fi = np.cumsum(fi)
Hi = np.cumsum(hi_rel)

freq_table = pd.DataFrame({
    "Intervalo"     : labels,
    "fi"            : fi,
    "hi  = fi/n"    : np.round(hi_rel, 4),
    "Fi (acum abs)" : Fi,
    "Hi (acum rel)" : np.round(Hi, 4),
})

print("\n" + "=" * 62)
print("TABLA DE FRECUENCIAS")
print("=" * 62)
print(freq_table.to_string(index=False))
print(f"\nVerificación: Σfi = {fi.sum()}  |  Hi final = {Hi[-1]:.4f}")

freq_table.to_csv(out_path("tabla_frecuencias.csv"), index=False)


# ╔══════════════════════════════════════════════════════════════════╗
# ║  2. MEDIDAS DE TENDENCIA CENTRAL                                 ║
# ╚══════════════════════════════════════════════════════════════════╝
"""
Cálculo de las medidas que indican el centro de la distribución.
- Media: Suma de todos los datos dividida por n.
- Mediana: Valor central de los datos ordenados (promedio de los dos 
  centrales si n es par).
- Moda: Valor con mayor frecuencia absoluta (el que más se repite).
"""

# ── 2.1 Media aritmética ──────────────────────────────────────────
groups  = [data[i * 10:(i + 1) * 10] for i in range(6)]
sums_g  = [int(g.sum()) for g in groups]
total   = sum(sums_g)
mean_   = total / n

print("\n" + "=" * 55)
print("MEDIA ARITMÉTICA — Paso a paso")
print("=" * 55)
print(f"  x  = {total} / {n} = {mean_:.4f} min")

# ── 2.2 Mediana ───────────────────────────────────────────────────
p30     = data_sorted[n // 2 - 1]      # x₃₀ = 20
p31     = data_sorted[n // 2]          # x₃₁ = 21
median_ = (p30 + p31) / 2

print("\n" + "=" * 55)
print("MEDIANA — Paso a paso")
print("=" * 55)
print(f"  n={n} (par) → promedio posiciones {n//2} y {n//2+1}")
print(f"  Mediana = ({p30} + {p31}) / 2 = {median_} min")

# ── 2.3 Moda ─────────────────────────────────────────────────────
vals, counts = np.unique(data, return_counts=True)
mode_val = int(vals[counts.argmax()])

print("\n" + "=" * 55)
print("MODA")
print("=" * 55)
print(f"  Moda = {mode_val} min  (Se repite {counts.max()} veces)")


# ╔══════════════════════════════════════════════════════════════════╗
# ║  3. MEDIDAS DE DISPERSIÓN                                        ║
# ╚══════════════════════════════════════════════════════════════════╝
"""
Cálculo de la variabilidad de los datos respecto a la media.
- Varianza Poblacional (σ²): Promedio de las desviaciones al cuadrado.
- Desviación Estándar Poblacional (σ): Raíz cuadrada de la varianza.
- Coeficiente de Variación (CV): Relación porcentual entre σ y la media.
- Error Estándar (SE): Precisión de la media muestral (σ / √n).
"""

deviations  = data - mean_          
dev_sq      = deviations ** 2       
sum_dev_sq  = dev_sq.sum()

# Varianza y Desviación Estándar
variance_   = sum_dev_sq / n
std_dev_    = np.sqrt(variance_)

# Coeficiente de Variación (CV)
CV = (std_dev_ / mean_) * 100

# Error Estándar de la Media (SE)
standard_error = std_dev_ / np.sqrt(n)

print("\n" + "=" * 55)
print("MEDIDAS DE DISPERSIÓN Y ERROR")
print("=" * 55)
print(f"  Varianza (σ²)      = {variance_:.4f} min²")
print(f"  Desviación Est (σ) = {std_dev_:.4f} min")
print(f"  Coef. Variación    = {CV:.2f}% (>30% indica alta dispersión)")
print(f"  Error Estándar     = {standard_error:.4f} min")


# ╔══════════════════════════════════════════════════════════════════╗
# ║  4. MEDIDAS DE POSICIÓN (CUARTILES, QUINTILES, PERCENTILES)      ║
# ╚══════════════════════════════════════════════════════════════════╝

def quantile_interp(arr_sorted, p):
    """
    Calcula un cuantil (medida de posición) usando interpolación lineal
    basada en la posición p*(n+1).
    
    Cómo funciona:
    1. Calcula la posición exacta: pos = p * (n + 1).
    2. Identifica las posiciones enteras inferior (floor) y superior (ceil).
    3. Extrae los valores del arreglo en esas posiciones.
    4. Aplica la fórmula de interpolación: Valor_Inf + decimal * (Valor_Sup - Valor_Inf).

    Parámetros:
        arr_sorted (np.ndarray): Arreglo de datos ordenados ascendentemente.
        p (float): Proporción a calcular (ej. 0.25 para Q1, 0.20 para K1).

    Retorna:
        q (float): El valor exacto del cuantil interpolado.
    """
    n_arr = len(arr_sorted)
    pos   = p * (n_arr + 1)
    lo_i  = int(pos)                            # Posición entera inferior (1-based)
    frac  = pos - lo_i                          # Parte decimal
    
    lo_i  = max(1, min(lo_i, n_arr))
    hi_i  = min(lo_i + 1, n_arr)
    
    lo_val = arr_sorted[lo_i - 1]               # Convertir a 0-based para Python
    hi_val = arr_sorted[hi_i - 1]
    
    q = lo_val + frac * (hi_val - lo_val)
    return q

# ── 4.1 Cuartiles (División en 4 partes: 25%, 50%, 75%) ────────────
Q1 = quantile_interp(data_sorted, 0.25)
Q2 = quantile_interp(data_sorted, 0.50)
Q3 = quantile_interp(data_sorted, 0.75)
IQR = Q3 - Q1
rango = int(data.max() - data.min())

# ── 4.2 Quintiles (División en 5 partes: 20%, 40%, 60%, 80%) ───────
K1 = quantile_interp(data_sorted, 0.20)
K2 = quantile_interp(data_sorted, 0.40)
K3 = quantile_interp(data_sorted, 0.60)
K4 = quantile_interp(data_sorted, 0.80)

# ── 4.3 Percentiles de interés (10% y 90%) ─────────────────────────
P10 = quantile_interp(data_sorted, 0.10)
P90 = quantile_interp(data_sorted, 0.90)

print("\n" + "=" * 60)
print("MEDIDAS DE POSICIÓN — Interpolación p(n+1)")
print("=" * 60)
print(f"  Cuartiles: Q1={Q1:.2f} | Q2={Q2:.2f} | Q3={Q3:.2f} (IQR={IQR:.2f})")
print(f"  Quintiles: K1={K1:.2f} | K2={K2:.2f} | K3={K3:.2f} | K4={K4:.2f}")
print(f"  Percentil 10: P10={P10:.2f} min")
print(f"  Percentil 90: P90={P90:.2f} min")


# ╔══════════════════════════════════════════════════════════════════╗
# ║  5. ASIMETRÍA Y CURTOSIS  (coeficientes de Fisher, poblacional)  ║
# ╚══════════════════════════════════════════════════════════════════╝
"""
Evaluación de la forma de la curva de distribución.
- Asimetría (g1): Mide el sesgo de la curva. Calculada con el momento
  central de orden 3. g1 > 0 indica asimetría positiva (cola derecha).
- Curtosis (g2): Mide el apuntalamiento. Calculada con el momento 
  central de orden 4 menos 3. g2 > 0 indica leptocurtosis (pico agudo).
"""

# ── 5.1 Asimetría de Fisher g₁ ───────────────────────────────────
dev3     = deviations ** 3
sum_dev3 = dev3.sum()
m3       = sum_dev3 / n                 # momento central de orden 3
sigma3   = std_dev_ ** 3
g1       = m3 / sigma3

# ── 5.2 Curtosis excess de Fisher g₂ ─────────────────────────────
dev4     = deviations ** 4
sum_dev4 = dev4.sum()
m4       = sum_dev4 / n                 # momento central de orden 4
sigma4   = variance_ ** 2               # σ⁴ = (σ²)²
g2       = m4 / sigma4 - 3

print("\n" + "=" * 55)
print("MEDIDAS DE FORMA")
print("=" * 55)
print(f"  Asimetría (g₁) = {g1:.4f} (>0 → Asimetría Positiva)")
print(f"  Curtosis (g₂)  = {g2:.4f} (>0 → Leptocúrtica)")


# ╔══════════════════════════════════════════════════════════════════╗
# ║  6. RESUMEN ESTADÍSTICO FINAL                                    ║
# ╚══════════════════════════════════════════════════════════════════╝

summary = pd.DataFrame({
    "Medida": [
        "Media (x̄)", "Mediana (Q2)", "Moda (Mo)",
        "Varianza (σ²)", "Desv. Estándar (σ)", "Coef. Variación (CV)", "Error Estándar (SE)",
        "Q1 (25%)", "Q3 (75%)", "IQR", "Rango",
        "K1 (20%)", "K4 (80%)", "P10 (10%)", "P90 (90%)",
        "Asimetría (g₁)", "Curtosis exceso (g₂)"
    ],
    "Valor": [
        f"{mean_:.4f} min", f"{median_} min", f"{mode_val} min",
        f"{variance_:.4f} min²", f"{std_dev_:.4f} min", f"{CV:.2f}%", f"{standard_error:.4f} min",
        f"{Q1:.2f} min", f"{Q3:.2f} min", f"{IQR:.2f} min", f"{rango} min",
        f"{K1:.2f} min", f"{K4:.2f} min", f"{P10:.2f} min", f"{P90:.2f} min",
        f"{g1:.4f}", f"{g2:.4f}"
    ]
})

print("\n" + "=" * 85)
print("RESUMEN ESTADÍSTICO DESCRIPTIVO COMPLETO — Generación Z (n=60)")
print("=" * 85)
print(summary.to_string(index=False))
summary.to_csv(out_path("resumen_estadistico_completo.csv"), index=False)


# ╔══════════════════════════════════════════════════════════════════╗
# ║  7. VISUALIZACIONES CON PLOTLY                                   ║
# ╚══════════════════════════════════════════════════════════════════╝
"""
Generación de gráficos para exportación (imágenes estáticas .png).
Incluye Histograma, Caja de Bigotes (Boxplot), Gráfica de Asimetría 
y Comparativa de Curtosis (Real vs Normal).
"""

bin_centers = [(BINS[i] + BINS[i + 1]) / 2 for i in range(len(BINS) - 1)]
BLUE        = "rgba(0,90,200,0.60)"
BLUE_LINE   = "rgba(0,60,160,0.90)"

# ── Fig 1: Histograma de frecuencias absolutas ────────────────────
fig1 = go.Figure(go.Bar(
    x=bin_centers, y=fi.tolist(), width=9.2,
    marker_color=BLUE,
    marker_line=dict(color=BLUE_LINE, width=1.5)
))
fig1.update_layout(
    title=dict(text="Histograma — Tiempo de Atención Gen Z (n=60)", x=0.5),
    xaxis=dict(title="Tiempo (min)", tickvals=BINS.tolist(), range=[-1, 102]),
    yaxis=dict(title="fi", range=[0, 23]),
    plot_bgcolor="white", showlegend=False,
    margin=dict(l=55, r=30, t=65, b=60),
)
fig1.write_image(out_path("fig1_histograma.png"))


# ── Fig 2: Diagrama de caja (Box plot) ───────────────────────────
"""
CORRECCIÓN: Se omite 'y=data' para construir la caja estrictamente 
con los valores precalculados (q1, median, q3, fences, mean).
Se usa 'x=["Atención"]' para darle una coordenada horizontal a la caja.
"""
fig2 = go.Figure(go.Box(
    x=["Atención"],                 # Coordenada X para centrar la caja
    q1=[Q1], 
    median=[Q2], 
    q3=[Q3],
    lowerfence=[float(data.min())],
    upperfence=[float(data.max())],
    mean=[mean_],                   # Se pasa explícitamente la media
    boxmean=True,                   # Dibuja la media (línea punteada / aspa)
    width=0.4,
    marker_color="rgba(0,90,200,0.80)",
    line=dict(color=BLUE_LINE, width=2),
    fillcolor="rgba(0,90,200,0.22)",
))

# Etiquetas de anotación
for val, lbl in [
    (Q1, f"Q1 = {Q1:.2f} min"),
    (Q2, f"Mediana = {Q2:.2f} min"),
    (Q3, f"Q3 = {Q3:.2f} min"),
]:
    fig2.add_annotation(
        x=0.65, y=val, xref="paper", yref="y",
        text=lbl, showarrow=False,
        font=dict(size=12, color="#1a1a2e"),
        xanchor="left",
        bgcolor="rgba(255,255,255,0.80)",
    )

fig2.update_layout(
    title=dict(text=f"Caja de Bigotes | IQR={IQR:.2f} min", x=0.5),
    yaxis=dict(title="Tiempo (min)", range=[0, 105]),
    xaxis=dict(showticklabels=False), # Ocultamos la etiqueta "Atención" del eje x para más limpieza
    plot_bgcolor="white", showlegend=False,
    margin=dict(l=55, r=120, t=65, b=40),
)

fig2.write_image(out_path("fig2_boxplot.png"))


# ── Fig 3: Histograma + Medidas (Asimetría) ──────────────────────
fig3 = go.Figure()
fig3.add_trace(go.Bar(
    x=bin_centers, y=fi.tolist(), width=9.2,
    marker_color="rgba(0,90,200,0.35)",
    marker_line=dict(color="rgba(0,60,160,0.60)", width=1),
    name="Frecuencia",
))
for xv, clr, dsh, nm in [
    (mode_val, "#e67e22", "dot",   f"Moda = {mode_val} min"),
    (median_,  "#27ae60", "dash",  f"Mediana = {median_} min"),
    (mean_,    "#c0392b", "solid", f"Media = {mean_:.2f} min"),
]:
    fig3.add_trace(go.Scatter(
        x=[xv, xv], y=[0, 22], mode="lines",
        line=dict(color=clr, dash=dsh, width=2.5), name=nm,
    ))
fig3.update_layout(
    title=dict(text="Asimetría Positiva: Moda < Mediana < Media", x=0.5),
    legend=dict(orientation="h", yanchor="bottom", y=1.04, xanchor="center", x=0.5, font=dict(size=11)),
    xaxis=dict(title="Tiempo (min)", tickvals=BINS.tolist(), range=[-1, 102]),
    yaxis=dict(title="fi", range=[0, 25]),
    plot_bgcolor="white", margin=dict(l=55, r=30, t=90, b=60),
)
fig3.write_image(out_path("fig3_medidas.png"))


# ── Fig 4: Densidad real vs curva normal (Curtosis) ──────────────
density  = [v / (n * 10) for v in fi.tolist()]
x_norm   = np.linspace(0, 100, 300)
y_norm   = sp_norm.pdf(x_norm, loc=mean_, scale=std_dev_)

fig4 = go.Figure()
fig4.add_trace(go.Bar(
    x=bin_centers, y=density, width=9.2,
    marker_color="rgba(0,90,200,0.45)",
    marker_line=dict(color="rgba(0,60,160,0.65)", width=1),
    name="Distribución real",
))
fig4.add_trace(go.Scatter(
    x=x_norm, y=y_norm, mode="lines",
    line=dict(color="#c0392b", width=2.5, dash="dash"),
    name=f"Normal (μ={mean_:.1f}, σ={std_dev_:.1f})",
))
fig4.update_layout(
    title=dict(text=f"Curtosis: Real vs Normal | g2={g2:.2f} (leptocúrtica)", x=0.5),
    legend=dict(orientation="h", yanchor="bottom", y=1.04, xanchor="center", x=0.5, font=dict(size=11)),
    xaxis=dict(title="Tiempo (min)", tickvals=BINS.tolist(), range=[-1, 102]),
    yaxis=dict(title="Densidad"),
    plot_bgcolor="white", margin=dict(l=60, r=30, t=90, b=60),
)
fig4.write_image(out_path("fig4_curtosis.png"))

# ╔══════════════════════════════════════════════════════════════════╗
# ║  8. ANÁLISIS DE HIPÓTESIS                                        ║
# ║                                                                  ║
# ║  Objetivo: Contrastar si la media poblacional del tiempo de      ║
# ║  atención de la Generación Z es igual, mayor o menor a 30 min.  ║
# ║                                                                  ║
# ║  Fundamento:                                                     ║
# ║  - H₀ (hipótesis nula): Afirmación de igualdad o statu quo.     ║
# ║    Se plantea que no existe diferencia significativa respecto    ║
# ║    al valor de referencia μ₀.                                    ║
# ║  - H₁ (hipótesis alternativa): Contradice a H₀. Se acepta       ║
# ║    únicamente si los datos proveen suficiente evidencia para     ║
# ║    rechazar H₀.                                                  ║
# ║                                                                  ║
# ║  Estadístico de prueba:                                          ║
# ║    Z = (x̄ - μ₀) / SE       donde  SE = σ / √n                  ║
# ║  Se usa Z porque n=60 (grande) y σ es conocida del muestreo.    ║
# ║                                                                  ║
# ║  Parámetros:                                                     ║
# ║    μ₀ = 30 min  (referencia)                                     ║
# ║    α  = 0.05                                                     ║
# ╚══════════════════════════════════════════════════════════════════╝


# ─── Parámetros de contraste ──────────────────────────────────────
mu_0   = 30          # Valor hipotético de la media poblacional
alpha  = 0.05        # Nivel de significancia
SE     = std_dev_ / np.sqrt(n)      # Error estándar de la media muestral

# Estadístico Z observado: mide cuántos errores estándar se aleja x̄ de μ₀
Z_obs = (mean_ - mu_0) / SE


print("=" * 62)
print("PARÁMETROS DEL CONTRASTE")
print("=" * 62)
print(f"  μ₀ (hipotético)       = {mu_0} min")
print(f"  x̄ (media muestral)   = {mean_:.4f} min")
print(f"  σ (desv. estándar)    = {std_dev_:.4f} min")
print(f"  SE (error estándar)   = {SE:.4f} min")
print(f"  n                     = {n}")
print(f"  α                     = {alpha}")
print(f"  Z_obs                 = {Z_obs:.4f}")


# ══════════════════════════════════════════════════════════════════
# 8.1  PRUEBA BILATERAL (dos colas)
# ──────────────────────────────────────────────────────────────────
#  H₀: μ = 30  → El tiempo medio de atención Gen Z es 30 min.
#  H₁: μ ≠ 30  → El tiempo medio es diferente de 30 min.
#
#  Región de rechazo: |Z_obs| > z_{α/2} = 1.96
#  Se divide α entre ambas colas (α/2 = 0.025 en cada lado).
# ══════════════════════════════════════════════════════════════════
z_crit_bilateral = sp_norm.ppf(1 - alpha / 2)       # z_{α/2} ≈ 1.96
p_bilateral      = 2 * (1 - sp_norm.cdf(abs(Z_obs)))
rechazar_bilateral = abs(Z_obs) > z_crit_bilateral

print("\\n" + "=" * 62)
print("PRUEBA BILATERAL (DOS COLAS)")
print("=" * 62)
print(f"  H₀: μ = {mu_0} min")
print(f"  H₁: μ ≠ {mu_0} min")
print(f"  Región de rechazo: |Z| > z_{{α/2}} = ±{z_crit_bilateral:.4f}")
print(f"  Z_obs = {Z_obs:.4f}  |  |Z_obs| = {abs(Z_obs):.4f}")
print(f"  p-valor = {p_bilateral:.4f}")
print(f"  Decisión (α=0.05): {'RECHAZAR H₀' if rechazar_bilateral else 'NO rechazar H₀'}")


# ══════════════════════════════════════════════════════════════════
# 8.2  PRUEBA UNILATERAL IZQUIERDA (cola izquierda)
# ──────────────────────────────────────────────────────────────────
#  H₀: μ ≥ 30  → El tiempo medio es al menos 30 min.
#  H₁: μ < 30  → El tiempo medio es menor de 30 min.
#
#  Región de rechazo: Z_obs < z_α = -1.645
#  Todo el α se concentra en la cola izquierda.
# ══════════════════════════════════════════════════════════════════
z_crit_izq       = sp_norm.ppf(alpha)                # z_α ≈ -1.645
p_unilateral_izq = sp_norm.cdf(Z_obs)
rechazar_izq     = Z_obs < z_crit_izq

print("\\n" + "=" * 62)
print("PRUEBA UNILATERAL IZQUIERDA (cola izquierda)")
print("=" * 62)
print(f"  H₀: μ ≥ {mu_0} min")
print(f"  H₁: μ < {mu_0} min")
print(f"  Región de rechazo: Z < z_α = {z_crit_izq:.4f}")
print(f"  Z_obs = {Z_obs:.4f}")
print(f"  p-valor = {p_unilateral_izq:.4f}")
print(f"  Decisión (α=0.05): {'RECHAZAR H₀' if rechazar_izq else 'NO rechazar H₀'}")


# ══════════════════════════════════════════════════════════════════
# 8.3  PRUEBA UNILATERAL DERECHA (cola derecha)
# ──────────────────────────────────────────────────────────────────
#  H₀: μ ≤ 30  → El tiempo medio es como máximo 30 min.
#  H₁: μ > 30  → El tiempo medio supera los 30 min.
#
#  Región de rechazo: Z_obs > z_α = +1.645
#  Todo el α se concentra en la cola derecha.
# ══════════════════════════════════════════════════════════════════
z_crit_der       = sp_norm.ppf(1 - alpha)             # z_α ≈ +1.645
p_unilateral_der = 1 - sp_norm.cdf(Z_obs)
rechazar_der     = Z_obs > z_crit_der

print("\\n" + "=" * 62)
print("PRUEBA UNILATERAL DERECHA (cola derecha)")
print("=" * 62)
print(f"  H₀: μ ≤ {mu_0} min")
print(f"  H₁: μ > {mu_0} min")
print(f"  Región de rechazo: Z > z_α = {z_crit_der:.4f}")
print(f"  Z_obs = {Z_obs:.4f}")
print(f"  p-valor = {p_unilateral_der:.4f}")
print(f"  Decisión (α=0.05): {'RECHAZAR H₀' if rechazar_der else 'NO rechazar H₀'}")


# ══════════════════════════════════════════════════════════════════
# 8.4  ERRORES DE DECISIÓN Y POTENCIA DE LA PRUEBA
# ──────────────────────────────────────────────────────────────────
#  Error Tipo I  (α): Rechazar H₀ cuando es verdadera.
#    → Probabilidad fijada por el investigador = 0.05 = 5%
#    → Consecuencia: falso positivo (concluir diferencia inexistente).
#
#  Error Tipo II (β): No rechazar H₀ cuando es falsa.
#    → Depende de la distancia entre μ₀ y el verdadero valor μ₁.
#    → Se calcula usando los límites de la región de aceptación.
#
#  Potencia (1-β): Probabilidad de rechazar H₀ correctamente cuando
#    es falsa. Una potencia alta (>0.80) indica una prueba sensible.
# ══════════════════════════════════════════════════════════════════

# Límites de la región de aceptación (en escala de x̄)
lower_lim = mu_0 - z_crit_bilateral * SE
upper_lim = mu_0 + z_crit_bilateral * SE

# β para un valor específico μ₁ = 35 min (escenario de ejemplo)
mu1_ejemplo = 35
z_lo        = (lower_lim - mu1_ejemplo) / SE
z_hi        = (upper_lim - mu1_ejemplo) / SE
beta_ej     = sp_norm.cdf(z_hi) - sp_norm.cdf(z_lo)   # P(aceptar H₀ | μ=35)
potencia_ej = 1 - beta_ej

print("\\n" + "=" * 62)
print("ERRORES EN LA PRUEBA DE HIPÓTESIS")
print("=" * 62)
print(f"  Error Tipo I  (α)          = {alpha:.4f}  →  {alpha*100:.1f}%")
print(f"  Error Tipo II (β) | μ₁=35  = {beta_ej:.4f}  →  {beta_ej*100:.1f}%")
print(f"  Potencia (1-β)    | μ₁=35  = {potencia_ej:.4f}  →  {potencia_ej*100:.1f}%")
print()
print("  Interpretación:")
print(f"    · α=0.05: el 5% de las veces rechazaríamos H₀ por azar.")
print(f"    · Si μ real fuera 35 min, en el {beta_ej*100:.1f}% de muestras")
print(f"      NO detectaríamos la diferencia (error tipo II).")
print(f"    · La prueba tiene {potencia_ej*100:.1f}% de potencia para detectar")
print(f"      que μ ≠ 30 cuando μ verdadera = 35 min.")


# ─── Tabla resumen ────────────────────────────────────────────────
tabla_hipotesis = pd.DataFrame({
    "Prueba":            ["Bilateral (2 colas)", "Unilateral Izquierda", "Unilateral Derecha"],
    "H₀":               [f"μ = {mu_0}", f"μ ≥ {mu_0}", f"μ ≤ {mu_0}"],
    "H₁":               [f"μ ≠ {mu_0}", f"μ < {mu_0}", f"μ > {mu_0}"],
    "Z_crítico":         [f"±{z_crit_bilateral:.4f}", f"{z_crit_izq:.4f}", f"{z_crit_der:.4f}"],
    "Z_obs":             [f"{Z_obs:.4f}" for _ in range(3)],
    "p-valor":           [f"{p_bilateral:.4f}", f"{p_unilateral_izq:.4f}", f"{p_unilateral_der:.4f}"],
    "Decisión (α=0.05)": ["NO rechazar H₀", "NO rechazar H₀", "NO rechazar H₀"],
})
tabla_hipotesis.to_csv(out_path(r"tabla_hipotesis.csv"), index=False)


# ─── Curva de potencia para rango de valores μ₁ ───────────────────
mu_alternatives = np.arange(20, 45, 1)
beta_arr  = np.array([sp_norm.cdf((upper_lim-m)/SE) - sp_norm.cdf((lower_lim-m)/SE)
                       for m in mu_alternatives])
power_arr = 1 - beta_arr


# ══════════════════════════════════════════════════════════════════
# VISUALIZACIONES — MÓDULO 8
# ══════════════════════════════════════════════════════════════════

OUTPUT_DIR = r"C:\Users\user\Desktop\Universidad\Quinto Semestre\Estadistica y Probabilidad\60 DATOS CODIGO\output"
os.makedirs(OUTPUT_DIR, exist_ok=True)

DARK_BLUE = "rgba(0,60,160,0.90)"
RED       = "rgba(192,57,43,0.80)"
ORANGE    = "rgba(230,126,34,0.85)"
x_z = np.linspace(-4, 4, 600)
y_z = sp_norm.pdf(x_z)

def shade_tail(x_range, color):
    xs = x_range
    ys = sp_norm.pdf(xs)
    return dict(
        x=np.concatenate([[xs[0]], xs, [xs[-1]]]),
        y=np.concatenate([[0], ys, [0]]),
        fill="toself", fillcolor=color,
        line_color="rgba(0,0,0,0)", showlegend=False, mode="lines"
    )


fig5a = go.Figure()
fig5a.add_trace(go.Scatter(x=x_z, y=y_z, mode="lines",
    line=dict(color=DARK_BLUE, width=2.5), name="N(0,1)"))
fig5a.add_trace(go.Scatter(**shade_tail(x_z[x_z <= -z_crit_bilateral], "rgba(192,57,43,0.40)")))
fig5a.add_trace(go.Scatter(**shade_tail(x_z[x_z >=  z_crit_bilateral], "rgba(192,57,43,0.40)")))
for xv, lbl in [(-z_crit_bilateral, f"-z_α/2 = {-z_crit_bilateral:.2f}"),
                ( z_crit_bilateral, f"+z_α/2 = +{z_crit_bilateral:.2f}")]:
    fig5a.add_vline(x=xv, line_dash="dash", line_color=RED,
                    annotation_text=lbl, annotation_position="top")
fig5a.add_vline(x=Z_obs, line_dash="dot", line_color=ORANGE,
    annotation_text=f"Z_obs = {Z_obs:.2f}", annotation_position="top right")
fig5a.update_layout(
    title=dict(text="Prueba Bilateral | H₀: μ=30  vs  H₁: μ≠30", x=0.5),
    xaxis=dict(title="Z"), yaxis=dict(title="f(Z)"),
    plot_bgcolor="white", showlegend=False,
    margin=dict(l=55, r=30, t=75, b=55),
)
fig5a.write_image(os.path.join(OUTPUT_DIR, "fig5a_bilateral.png"), width=820, height=420)


# ── Fig 5b: Prueba unilateral izquierda ──────────────────────────
fig5b = go.Figure()
fig5b.add_trace(go.Scatter(x=x_z, y=y_z, mode="lines",
    line=dict(color=DARK_BLUE, width=2.5)))
fig5b.add_trace(go.Scatter(**shade_tail(x_z[x_z <= z_crit_izq], "rgba(192,57,43,0.40)")))
fig5b.add_vline(x=z_crit_izq, line_dash="dash", line_color=RED,
    annotation_text=f"z_α = {z_crit_izq:.2f}", annotation_position="top")
fig5b.add_vline(x=Z_obs, line_dash="dot", line_color=ORANGE,
    annotation_text=f"Z_obs = {Z_obs:.2f}", annotation_position="top right")
fig5b.update_layout(
    title=dict(text="Prueba Unilateral Izquierda | H₀: μ≥30  vs  H₁: μ<30", x=0.5),
    xaxis=dict(title="Z"), yaxis=dict(title="f(Z)"),
    plot_bgcolor="white", showlegend=False,
    margin=dict(l=55, r=30, t=75, b=55),
)
fig5b.write_image(os.path.join(OUTPUT_DIR, "fig5b_unilateral_izq.png"), width=820, height=420)


# ── Fig 5c: Prueba unilateral derecha ────────────────────────────
fig5c = go.Figure()
fig5c.add_trace(go.Scatter(x=x_z, y=y_z, mode="lines",
    line=dict(color=DARK_BLUE, width=2.5)))
fig5c.add_trace(go.Scatter(**shade_tail(x_z[x_z >= z_crit_der], "rgba(192,57,43,0.40)")))
fig5c.add_vline(x=z_crit_der, line_dash="dash", line_color=RED,
    annotation_text=f"z_α = {z_crit_der:.2f}", annotation_position="top")
fig5c.add_vline(x=Z_obs, line_dash="dot", line_color=ORANGE,
    annotation_text=f"Z_obs = {Z_obs:.2f}", annotation_position="top right")
fig5c.update_layout(
    title=dict(text="Prueba Unilateral Derecha | H₀: μ≤30  vs  H₁: μ>30", x=0.5),
    xaxis=dict(title="Z"), yaxis=dict(title="f(Z)"),
    plot_bgcolor="white", showlegend=False,
    margin=dict(l=55, r=30, t=75, b=55),
)
fig5c.write_image(os.path.join(OUTPUT_DIR, "fig5c_unilateral_der.png"), width=820, height=420)


# ── Fig 6: Curva de Potencia ──────────────────────────────────────
fig6 = go.Figure()
fig6.add_trace(go.Scatter(
    x=mu_alternatives, y=beta_arr, mode="lines+markers",
    line=dict(color="rgba(192,57,43,0.85)", width=2.5, dash="dash"),
    marker=dict(size=5), name="β (Error Tipo II)",
))
fig6.add_trace(go.Scatter(
    x=mu_alternatives, y=power_arr, mode="lines+markers",
    line=dict(color="rgba(0,90,200,0.85)", width=2.5),
    marker=dict(size=5), name="Potencia (1 − β)",
))
fig6.add_hline(y=alpha, line_dash="dot", line_color="rgba(230,126,34,0.85)")
fig6.add_annotation(x=44, y=alpha+0.03, text=f"α = {alpha}",
    showarrow=False, font=dict(size=12, color="rgba(200,100,0,1)"))
fig6.add_vline(x=mu_0, line_dash="dash", line_color="rgba(80,80,80,0.50)")
fig6.add_annotation(x=mu_0+0.4, y=0.97, text=f"μ₀ = {mu_0}",
    showarrow=False, font=dict(size=12, color="rgba(80,80,80,1)"), xanchor="left")
fig6.add_trace(go.Scatter(
    x=[mu1_ejemplo], y=[potencia_ej], mode="markers",
    marker=dict(size=13, color="rgba(39,174,96,0.95)", symbol="circle",
                line=dict(color="white", width=2)),
    name=f"μ₁ = {mu1_ejemplo} min  (Pot.={potencia_ej:.2f})",
))
fig6.update_layout(
    title=dict(text="Curva de Potencia — Prueba Bilateral (α = 0.05)", x=0.5,
               font=dict(size=15)),
    xaxis=dict(title="Valor verdadero μ₁ (min)", range=[19, 46]),
    yaxis=dict(title="Probabilidad", range=[-0.02, 1.05]),
    legend=dict(x=0.02, y=0.98, bgcolor="rgba(255,255,255,0.85)",
                bordercolor="rgba(180,180,180,0.5)", borderwidth=1),
    plot_bgcolor="white", margin=dict(l=70, r=50, t=75, b=65),
)
fig6.write_image(os.path.join(OUTPUT_DIR, "fig6_curva_potencia.png"), width=820, height=450)


print("\n✓ fig5a, fig5b, fig5c, fig6 guardadas en output/")
print("✓ tabla_hipotesis.csv guardado en output/")